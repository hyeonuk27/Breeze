-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k5a202.p.ssafy.io    Database: breeze
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments_participant`
--

DROP TABLE IF EXISTS `appointments_participant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments_participant` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `time` int NOT NULL,
  `barami_type` int NOT NULL,
  `appointment_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `appointments_partici_appointment_id_34086855_fk_appointme` (`appointment_id`),
  CONSTRAINT `appointments_partici_appointment_id_34086855_fk_appointme` FOREIGN KEY (`appointment_id`) REFERENCES `appointments_appointment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=270 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments_participant`
--

LOCK TABLES `appointments_participant` WRITE;
/*!40000 ALTER TABLE `appointments_participant` DISABLE KEYS */;
INSERT INTO `appointments_participant` VALUES (64,'야호',15,0,31),(65,'테스트',14,1,31),(79,'1',14,0,36),(80,'2',17,1,36),(81,'ㅂ',67,0,37),(82,'ㅋ',204,1,37),(83,'ㅂㅂ',63,0,38),(84,'ㅋㅋ',144,1,38),(92,'ㅅ',5,0,42),(93,'ㅁ',0,1,42),(96,'ㅇㅇ',227,0,44),(97,'ㅁㅁ',74,1,44),(102,'ㅁ',3,0,47),(103,'ㅁㅁ',3,1,47),(143,'야호',10,0,67),(144,'테스트',13,1,67),(147,'1',16,0,69),(148,'2',15,1,69),(155,'1',16,0,73),(156,'2',22,1,73),(157,'1',13,0,74),(158,'2',24,1,74),(161,'1',21,0,76),(162,'2',14,1,76),(163,'1',2,0,77),(164,'2',2,1,77),(165,'1',13,0,78),(166,'2',13,1,78),(167,'1',2,0,79),(168,'2',2,1,79),(173,'ㅂㅁ',2,0,82),(174,'ㅁㅁ',2,1,82),(175,'1',5,0,83),(176,'ㄷㄷ',2,1,83),(177,'지도테스트',24,0,84),(178,'2',30,1,84),(181,'ㅅㄷ',26,0,86),(182,'테스트',22,1,86),(185,'현욱',10,0,88),(186,'현욱',17,1,88),(190,'ㅅ',20,0,90),(191,'ㅗ',26,1,90),(192,'1',12,0,91),(193,'2',8,1,91),(194,'제발',28,0,92),(195,'노에러...',24,1,92),(198,'1',26,0,94),(199,'저기',25,1,94),(202,'탬',36,0,96),(203,'미정',17,1,96),(204,'현욱',12,2,96),(205,'혜원',49,0,97),(206,'현욱',46,1,97),(220,'채니챈',65,1,101),(221,'현욱킴',51,2,101),(222,'지미짐',33,3,101),(223,'수빙수',51,4,101),(224,'교져스',45,0,101),(230,'채니챈',24,1,104),(231,'현욱킴',16,2,104),(232,'지미짐',28,3,104),(233,'수빙수',22,4,104),(234,'교저스',19,0,104),(235,'김싸피',14,5,104),(238,'채니챈',24,1,106),(239,'현욱킴',16,2,106),(240,'지미짐',28,3,106),(241,'수빙수',22,4,106),(242,'교저스',19,0,106),(243,'김싸피',14,5,106),(244,'삭제테스트',9,0,107),(245,'삭제',11,1,107),(250,'뽀로로',14,0,109),(251,'포비',20,1,109),(252,'크롱',29,2,109),(253,'루피',26,3,109),(258,'뽀로로',11,0,112),(259,'포비',19,1,112),(260,'크롱',25,2,112),(261,'루피',22,3,112),(262,'뽀로로',11,0,113),(263,'포비',20,1,113),(264,'크롱',24,2,113),(265,'루피',24,3,113),(266,'뽀로로',10,0,114),(267,'포비',20,1,114),(268,'크롱',26,2,114),(269,'루피',24,3,114);
/*!40000 ALTER TABLE `appointments_participant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-17 17:34:57
