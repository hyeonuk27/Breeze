-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: k5a202.p.ssafy.io    Database: breeze
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments_appointmentplace`
--

DROP TABLE IF EXISTS `appointments_appointmentplace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments_appointmentplace` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `category` int NOT NULL,
  `url` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `appointment_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `appointments_appoint_appointment_id_37f8f220_fk_appointme` (`appointment_id`),
  CONSTRAINT `appointments_appoint_appointment_id_37f8f220_fk_appointme` FOREIGN KEY (`appointment_id`) REFERENCES `appointments_appointment` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments_appointmentplace`
--

LOCK TABLES `appointments_appointmentplace` WRITE;
/*!40000 ALTER TABLE `appointments_appointmentplace` DISABLE KEYS */;
INSERT INTO `appointments_appointmentplace` VALUES (50,'고창복의낙지세상 봉천점',0,'http://place.map.kakao.com/18546321',31),(62,'하카타분코',0,'http://place.map.kakao.com/21410206',36),(63,'호담',0,'http://place.map.kakao.com/13927831',37),(64,'제비골영양탕',0,'http://place.map.kakao.com/10723100',38),(70,'아웃백스테이크하우스 서울대점',0,'http://place.map.kakao.com/7991184',42),(73,'제비골영양탕',0,'http://place.map.kakao.com/10723100',44),(76,'돝고기506',0,'http://place.map.kakao.com/1511737742',47),(121,'옷살',0,'http://place.map.kakao.com/12740961',67),(122,'라이라이켄',0,'http://place.map.kakao.com/2067688877',67),(123,'교자킹',2,'http://place.map.kakao.com/1575341944',67),(125,'영원식당',0,'http://place.map.kakao.com/13289961',69),(129,'도레도레 롯데백화점 영등포점',1,'http://place.map.kakao.com/609292637',73),(130,'커피바이',1,'http://place.map.kakao.com/438591937',74),(132,'영원식당',0,'http://place.map.kakao.com/13289961',76),(133,'라공방 강남1호 본점',0,'http://place.map.kakao.com/146674691',77),(134,'해주냉면',0,'http://place.map.kakao.com/25049102',78),(135,'청류벽',0,'http://place.map.kakao.com/770095922',79),(138,'빌즈 강남',0,'http://place.map.kakao.com/1469510606',82),(139,'청류벽',0,'http://place.map.kakao.com/770095922',83),(140,'오오사',0,'http://place.map.kakao.com/1591624876',84),(144,'육수당 노량진점',0,'http://place.map.kakao.com/1551595846',86),(145,'삼삼가마솥돈까스앤 칡불냉면',0,'http://place.map.kakao.com/1718067783',86),(146,'해물포차땅굴',2,'http://place.map.kakao.com/1445944171',86),(148,'간코',0,'http://place.map.kakao.com/1709213598',88),(149,'오레노라멘 합정본점',0,'http://place.map.kakao.com/1916682638',88),(156,'부다스벨리 이태원점',0,'http://place.map.kakao.com/17011339',90),(157,'바토스 이태원점',0,'http://place.map.kakao.com/21535686',90),(158,'부타이',0,'http://place.map.kakao.com/1337569618',91),(159,'페스타 바이 민구',0,'http://place.map.kakao.com/21439806',92),(164,'스마일이촌떡볶이',0,'http://place.map.kakao.com/8056170',94),(165,'테바사키반초 이촌역점',2,'http://place.map.kakao.com/1080329146',94),(166,'뉴오리진 동부이촌점',1,'http://place.map.kakao.com/869574538',94),(170,'합정 타오마라탕',0,'http://place.map.kakao.com/92793209',96),(171,'디벙크',1,'http://place.map.kakao.com/1040119941',96),(172,'무니',2,'http://place.map.kakao.com/1468816223',96),(173,'교촌치킨 녹양점',0,'http://place.map.kakao.com/10137074',97),(174,'원조뒷고기 녹양역점',0,'http://place.map.kakao.com/1242060712',97),(175,'24시전주명가콩나물국밥 녹양점',0,'http://place.map.kakao.com/227503987',97),(176,'탐앤탐스 녹양역점',1,'http://place.map.kakao.com/27510487',97),(177,'포차천국 녹양역점',2,'http://place.map.kakao.com/888829915',97),(178,'세미포차',2,'http://place.map.kakao.com/1487762802',97),(179,'알바트로스',2,'http://place.map.kakao.com/15864849',97),(180,'커피마마 녹양점',1,'http://place.map.kakao.com/2136508409',97),(200,'미도인 성수',0,'http://place.map.kakao.com/2065662781',101),(201,'카페노티드 성수',1,'http://place.map.kakao.com/1325105515',101),(202,'어메이징브루잉컴퍼니 성수브루펍',2,'http://place.map.kakao.com/27474832',101),(205,'무월식탁 파미에스테이션점',0,'http://place.map.kakao.com/1966365851',104),(206,'그루빙하이',2,'http://place.map.kakao.com/13582081',104),(210,'무월식탁 파미에스테이션점',0,'http://place.map.kakao.com/1966365851',106),(211,'세라젬웰카페 반포직영점',1,'http://place.map.kakao.com/971038927',106),(212,'하얀집호프',2,'http://place.map.kakao.com/16326700',106),(213,'폴바셋 신세계백화점강남점',1,'http://place.map.kakao.com/11831543',106),(214,'서래향',0,'http://place.map.kakao.com/26533341',106),(215,'르물랑서래',2,'http://place.map.kakao.com/1204868230',106),(216,'비언유주얼',0,'http://place.map.kakao.com/1327269053',107),(223,'파이프',0,'http://place.map.kakao.com/24944823',109),(224,'모터시티바이매니멀 본점',0,'http://place.map.kakao.com/124338573',109),(225,'키에리 이태원점',1,'http://place.map.kakao.com/800587300',109),(226,'앤트러사이트 한남점',1,'http://place.map.kakao.com/27344582',109),(227,'미도리야',2,'http://place.map.kakao.com/24985617',109),(228,'주휴소',2,'http://place.map.kakao.com/2029395450',109),(229,'이태원교집합',2,'http://place.map.kakao.com/761695641',109),(234,'파이프',0,'http://place.map.kakao.com/24944823',112),(235,'명동교자 이태원점',0,'http://place.map.kakao.com/1952478679',112),(236,'챔프커피 2작업실',1,'http://place.map.kakao.com/1143868163',112),(237,'헬카페',1,'http://place.map.kakao.com/25548485',112),(238,'이태원계단집',2,'http://place.map.kakao.com/931765532',112),(239,'쿠로이야',2,'http://place.map.kakao.com/1447978994',112),(240,'꾸띠자르당',0,'http://place.map.kakao.com/26928254',113),(241,'명동교자 이태원점',0,'http://place.map.kakao.com/1952478679',113),(242,'챔프커피 2작업실',1,'http://place.map.kakao.com/1143868163',113),(243,'무진장',1,'http://place.map.kakao.com/954423286',113),(244,'이태원교집합',2,'http://place.map.kakao.com/761695641',113),(245,'쿠로이야',2,'http://place.map.kakao.com/1447978994',113),(246,'명동교자 이태원점',0,'http://place.map.kakao.com/1952478679',114),(247,'꾸띠자르당',0,'http://place.map.kakao.com/26928254',114),(248,'챔프커피 2작업실',1,'http://place.map.kakao.com/1143868163',114),(249,'무진장',1,'http://place.map.kakao.com/954423286',114),(250,'이태원계단집',2,'http://place.map.kakao.com/931765532',114),(251,'쿠로이야',2,'http://place.map.kakao.com/1447978994',114);
/*!40000 ALTER TABLE `appointments_appointmentplace` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-17 17:35:04
